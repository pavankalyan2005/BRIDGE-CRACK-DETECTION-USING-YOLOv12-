"""
High-Fidelity Bridge Inspection Sample Data Generator
Generates realistic concrete textures, cracks, spalling, and rebar defects for immediate out-of-the-box demonstration.
"""

import os
from pathlib import Path
import cv2
import numpy as np
from core.config import SAMPLE_DIR
from core.logger import logger

def create_concrete_base_texture(width: int = 768, height: int = 768, base_gray: int = 150) -> np.ndarray:
    """Generates realistic concrete surface with multi-scale Perlin/Gaussian aggregate noise."""
    np.random.seed(42)
    # Multi-octave concrete texture
    img = np.full((height, width, 3), base_gray, dtype=np.float32)

    # Coarse aggregates
    noise_coarse = cv2.resize(np.random.normal(0, 25, (height // 16, width // 16)), (width, height))
    # Medium sand / cement paste
    noise_med = cv2.resize(np.random.normal(0, 15, (height // 4, width // 4)), (width, height))
    # Fine grain
    noise_fine = np.random.normal(0, 8, (height, width))

    combined_noise = noise_coarse * 0.5 + noise_med * 0.35 + noise_fine * 0.15
    for c in range(3):
        img[:, :, c] += combined_noise

    # Concrete color tint (slight warmth/coolness)
    img[:, :, 0] -= 4.0  # Blue
    img[:, :, 2] += 2.0  # Red

    # Formwork line / subtle seam
    seam_y = height // 3
    cv2.line(img, (0, seam_y), (width, seam_y), (base_gray - 12, base_gray - 12, base_gray - 12), 1)

    return np.clip(img, 20, 240).astype(np.uint8)

def draw_realistic_crack(
    img: np.ndarray,
    start_pt: tuple,
    end_pt: tuple,
    main_width: int = 3,
    branches: int = 4,
    color: tuple = (30, 30, 30),
    random_seed: int = 100
) -> np.ndarray:
    """Draws jagged, branching natural concrete crack with variable width and shadow."""
    np.random.seed(random_seed)
    h, w = img.shape[:2]
    
    # Generate jagged path using midpoint displacement / random walk
    steps = 45
    xs = np.linspace(start_pt[0], end_pt[0], steps)
    ys = np.linspace(start_pt[1], end_pt[1], steps)
    
    path = []
    for i in range(steps):
        jitter_x = np.random.normal(0, 6.0)
        jitter_y = np.random.normal(0, 6.0)
        px = int(np.clip(xs[i] + jitter_x, 5, w - 5))
        py = int(np.clip(ys[i] + jitter_y, 5, h - 5))
        path.append((px, py))

    # Draw main crack segments with depth gradient
    for i in range(len(path) - 1):
        pt1, pt2 = path[i], path[i+1]
        local_w = max(1, int(main_width + np.random.choice([-1, 0, 1, 1])))
        
        # Soft outer shadow
        cv2.line(img, pt1, pt2, (color[0] + 40, color[1] + 40, color[2] + 40), local_w + 3)
        # Main dark fissure
        cv2.line(img, pt1, pt2, color, local_w)
        # Micro edge highlight
        cv2.line(img, (pt1[0]+1, pt1[1]+1), (pt2[0]+1, pt2[1]+1), (180, 180, 180), 1)

    # Draw natural branches
    for b in range(branches):
        branch_idx = np.random.randint(5, len(path) - 10)
        b_start = path[branch_idx]
        angle = np.random.uniform(0.3, 1.2) * np.random.choice([-1, 1])
        b_len = np.random.randint(40, 120)
        
        bx_end = int(np.clip(b_start[0] + b_len * np.cos(angle), 5, w - 5))
        by_end = int(np.clip(b_start[1] + b_len * np.sin(angle), 5, h - 5))
        
        b_steps = 15
        b_xs = np.linspace(b_start[0], bx_end, b_steps)
        b_ys = np.linspace(b_start[1], by_end, b_steps)
        
        b_path = [b_start]
        for j in range(1, b_steps):
            b_path.append((
                int(np.clip(b_xs[j] + np.random.normal(0, 3), 5, w - 5)),
                int(np.clip(b_ys[j] + np.random.normal(0, 3), 5, h - 5))
            ))
            
        for j in range(len(b_path) - 1):
            cv2.line(img, b_path[j], b_path[j+1], (color[0] + 15, color[1] + 15, color[2] + 15), max(1, main_width - 1))

    return img

def generate_all_samples():
    """Generates all preset demonstration bridge inspection imagery."""
    SAMPLE_DIR.mkdir(parents=True, exist_ok=True)
    logger.info("Generating realistic bridge inspection sample images...")

    # Sample 1: Longitudinal Deck Crack
    img1 = create_concrete_base_texture(800, 800, base_gray=145)
    img1 = draw_realistic_crack(img1, (120, 80), (680, 720), main_width=4, branches=5, random_seed=101)
    # Add minor oil stain
    cv2.circle(img1, (300, 450), 45, (120, 115, 110), -1)
    img1 = cv2.GaussianBlur(img1, (3, 3), 0)
    cv2.imwrite(str(SAMPLE_DIR / "sample_1_deck_longitudinal_crack.jpg"), img1)

    # Sample 2: Pier Transverse Shear Crack with Efflorescence
    img2 = create_concrete_base_texture(800, 800, base_gray=135)
    img2 = draw_realistic_crack(img2, (80, 420), (720, 380), main_width=5, branches=4, random_seed=202)
    # Efflorescence white calcite leaching streaks
    for x_pos in [280, 420, 560]:
        overlay = img2.copy()
        cv2.ellipse(overlay, (x_pos, 440), (25, 120), 10, 0, 360, (220, 225, 230), -1)
        img2 = cv2.addWeighted(overlay, 0.45, img2, 0.55, 0)
    cv2.imwrite(str(SAMPLE_DIR / "sample_2_pier_transverse_crack.jpg"), img2)

    # Sample 3: Girder Spalling and Exposed Corroded Rebar
    img3 = create_concrete_base_texture(800, 800, base_gray=150)
    # Spalling crater cavity
    spall_center = (400, 400)
    cv2.ellipse(img3, spall_center, (170, 110), 15, 0, 360, (80, 75, 70), -1)
    # Exposed rebar bars (Rust Orange #CC4400 / #8B2500)
    for ry in [370, 425]:
        cv2.line(img3, (260, ry), (540, ry + 15), (20, 50, 180), 8) # Rust BGR
        # Ribbed rebar pattern
        for rx in range(270, 530, 12):
            cv2.line(img3, (rx, ry - 3), (rx + 4, ry + 12), (10, 30, 140), 2)
    # Cracks radiating from spall
    img3 = draw_realistic_crack(img3, (530, 420), (740, 550), main_width=3, branches=2, random_seed=303)
    img3 = draw_realistic_crack(img3, (260, 380), (90, 250), main_width=3, branches=2, random_seed=304)
    cv2.imwrite(str(SAMPLE_DIR / "sample_3_girder_spall_rebar.jpg"), img3)

    # Sample 4: Alligator / Fatigue Map Cracking
    img4 = create_concrete_base_texture(800, 800, base_gray=140)
    # Generate interconnected network
    nodes = [(np.random.randint(100, 700), np.random.randint(100, 700)) for _ in range(14)]
    for i in range(len(nodes)):
        for j in range(i + 1, min(i + 4, len(nodes))):
            dist = np.hypot(nodes[i][0] - nodes[j][0], nodes[i][1] - nodes[j][1])
            if dist < 260:
                img4 = draw_realistic_crack(img4, nodes[i], nodes[j], main_width=2, branches=1, random_seed=i*10+j)
    cv2.imwrite(str(SAMPLE_DIR / "sample_4_alligator_fatigue_cracking.jpg"), img4)

    # Sample 5: Expansion Joint Damage & Edge Cavity
    img5 = create_concrete_base_texture(800, 800, base_gray=155)
    # Heavy joint line
    cv2.line(img5, (400, 0), (400, 800), (25, 25, 25), 18)
    cv2.line(img5, (390, 0), (390, 800), (90, 90, 90), 2)
    cv2.line(img5, (410, 0), (410, 800), (90, 90, 90), 2)
    # Broken joint edge / spall
    cv2.ellipse(img5, (395, 350), (45, 80), 0, 0, 360, (70, 65, 60), -1)
    img5 = draw_realistic_crack(img5, (390, 320), (180, 260), main_width=3, branches=2, random_seed=505)
    cv2.imwrite(str(SAMPLE_DIR / "sample_5_expansion_joint_damage.jpg"), img5)

    # Sample 6: Healthy Benchmark Deck
    img6 = create_concrete_base_texture(800, 800, base_gray=160)
    # Clean expansion stripe
    cv2.line(img6, (50, 400), (750, 400), (135, 135, 135), 2)
    cv2.imwrite(str(SAMPLE_DIR / "sample_6_healthy_benchmark_deck.jpg"), img6)

    logger.info("All 6 bridge sample inspection datasets successfully generated!")

if __name__ == "__main__":
    generate_all_samples()
