"""
CSV Exporter for BridgeVisionNet Defect Measurements
"""

import csv
from pathlib import Path
from typing import Dict, Any, List
from core.config import REPORTS_DIR

def export_inspection_csv(inspection_id: str, data: Dict[str, Any]) -> str:
    csv_filename = f"Inspection_{inspection_id}_data.csv"
    csv_path = REPORTS_DIR / csv_filename

    metrology = data.get("metrology", {})
    health = data.get("health_assessment", {})
    detections = data.get("detections", [])

    with open(csv_path, mode="w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["BridgeVisionNet Structural Health Log"])
        writer.writerow(["Inspection ID", inspection_id])
        writer.writerow(["Structure Tag", data.get("component_name", "Deck")])
        writer.writerow(["GPS Coordinates", data.get("gps_coords", "N/A")])
        writer.writerow(["Structural Health Index (SHI)", health.get("structural_health_index", "")])
        writer.writerow(["AASHTO Rating", health.get("condition_state", "")])
        writer.writerow(["Max Crack Width (mm)", metrology.get("max_width_mm", 0.0)])
        writer.writerow(["Avg Crack Width (mm)", metrology.get("avg_width_mm", 0.0)])
        writer.writerow(["Total Length (mm)", metrology.get("total_length_mm", 0.0)])
        writer.writerow(["Surface Area (mm2)", metrology.get("surface_area_mm2", 0.0)])
        writer.writerow(["Branch Count", metrology.get("branch_count", 0)])
        writer.writerow([])
        writer.writerow(["Defect Detections"])
        writer.writerow(["Defect Index", "Class Name", "Box_X1", "Box_Y1", "Box_X2", "Box_Y2", "Confidence", "Severity Weight"])
        for i, d in enumerate(detections, 1):
            box = d.get("box", [0, 0, 0, 0])
            writer.writerow([
                i, d.get("class_name", ""),
                box[0], box[1], box[2], box[3],
                d.get("score", 0.0), d.get("severity_weight", 1.0)
            ])

    return str(csv_path)
