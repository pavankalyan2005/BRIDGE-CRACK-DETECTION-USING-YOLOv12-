/**
 * BridgeVisionNet: 3D Bridge Digital Twin
 * Three.js Interactive Structural Model with 3D Defect Hotspots & Dynamic Inspection Mapping
 */

class BridgeDigitalTwin {
  constructor(containerId) {
    this.container = document.getElementById(containerId);
    if (!this.container) return;

    this.scene = null;
    this.camera = null;
    this.renderer = null;
    this.controls = null;
    this.hotspots = [];
    this.raycaster = new THREE.Raycaster();
    this.mouse = new THREE.Vector2();
    this.hoveredObject = null;
    this.animationId = null;

    this.init();
  }

  init() {
    const width = this.container.clientWidth || 800;
    const height = this.container.clientHeight || 500;

    // 1. Scene
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x050B14);
    this.scene.fog = new THREE.FogExp2(0x050B14, 0.008);

    // 2. Camera
    this.camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    this.camera.position.set(60, 35, 75);

    // 3. Renderer
    this.renderer = new THREE.WebGLRenderer({ antialias: true });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.container.appendChild(this.renderer.domElement);

    // 4. Controls
    if (THREE.OrbitControls) {
      this.controls = new THREE.OrbitControls(this.camera, this.renderer.domElement);
      this.controls.enableDamping = true;
      this.controls.dampingFactor = 0.05;
      this.controls.maxPolarAngle = Math.PI / 2 - 0.02;
      this.controls.minDistance = 15;
      this.controls.maxDistance = 200;
      this.controls.target.set(0, 10, 0);
    }

    // 5. Lighting
    const ambientLight = new THREE.AmbientLight(0x223344, 1.2);
    this.scene.add(ambientLight);

    const dirLight = new THREE.DirectionalLight(0x90E0EF, 2.0);
    dirLight.position.set(50, 80, 40);
    dirLight.castShadow = true;
    this.scene.add(dirLight);

    const pointLight = new THREE.PointLight(0x00B4D8, 2, 80);
    pointLight.position.set(0, 25, 0);
    this.scene.add(pointLight);

    // 6. Build Bridge Geometry
    this.buildBridgeModel();

    // 7. Grid Horizon & Water
    this.buildEnvironment();

    // 8. Add 3D Defect Hotspots
    this.addDefectHotspots();

    // 9. Event Listeners
    window.addEventListener('resize', () => this.onResize());
    this.container.addEventListener('mousemove', (e) => this.onMouseMove(e));
    this.container.addEventListener('click', (e) => this.onClick(e));

    // 10. Animation Loop
    this.animate();
  }

  buildBridgeModel() {
    this.bridgeGroup = new THREE.Group();

    // Material definitions
    const concreteMat = new THREE.MeshStandardMaterial({
      color: 0x4A5568,
      roughness: 0.8,
      metalness: 0.1
    });

    const deckMat = new THREE.MeshStandardMaterial({
      color: 0x2D3748,
      roughness: 0.6,
      metalness: 0.3
    });

    const cableMat = new THREE.MeshStandardMaterial({
      color: 0x00B4D8,
      roughness: 0.3,
      metalness: 0.8,
      emissive: 0x005F73,
      emissiveIntensity: 0.3
    });

    const pylonMat = new THREE.MeshStandardMaterial({
      color: 0x718096,
      roughness: 0.7,
      metalness: 0.2
    });

    // Main Deck
    const deckGeo = new THREE.BoxGeometry(140, 2.5, 14);
    const deckMesh = new THREE.Mesh(deckGeo, deckMat);
    deckMesh.position.set(0, 15, 0);
    deckMesh.castShadow = true;
    deckMesh.receiveShadow = true;
    deckMesh.userData = { name: "Bridge Deck Span D-04", health: 86, type: "Deck" };
    this.bridgeGroup.add(deckMesh);

    // Roadway Stripe
    const stripeGeo = new THREE.BoxGeometry(138, 0.1, 0.6);
    const stripeMat = new THREE.MeshBasicMaterial({ color: 0xFFB703 });
    const stripeMesh = new THREE.Mesh(stripeGeo, stripeMat);
    stripeMesh.position.set(0, 16.3, 0);
    this.bridgeGroup.add(stripeMesh);

    // Support Pylons / Towers (2 towers)
    const pylonGeo = new THREE.BoxGeometry(4, 50, 4);
    [-30, 30].forEach((posX, idx) => {
      const pylon1 = new THREE.Mesh(pylonGeo, pylonMat);
      pylon1.position.set(posX, 25, -6);
      pylon1.castShadow = true;
      pylon1.userData = { name: `Main Tower Pylon #${idx + 1}`, health: 92, type: "Pylon" };
      this.bridgeGroup.add(pylon1);

      const pylon2 = new THREE.Mesh(pylonGeo, pylonMat);
      pylon2.position.set(posX, 25, 6);
      pylon2.castShadow = true;
      this.bridgeGroup.add(pylon2);

      // Crossbeam
      const crossGeo = new THREE.BoxGeometry(4.2, 3, 14);
      const cross = new THREE.Mesh(crossGeo, pylonMat);
      cross.position.set(posX, 42, 0);
      this.bridgeGroup.add(cross);

      // Pier Foundation
      const pierGeo = new THREE.CylinderGeometry(5, 6, 20, 16);
      const pierMesh = new THREE.Mesh(pierGeo, concreteMat);
      pierMesh.position.set(posX, 5, 0);
      pierMesh.receiveShadow = true;
      pierMesh.userData = { name: `Substructure Pier #${idx + 1}`, health: 68, type: "Pier" };
      this.bridgeGroup.add(pierMesh);
    });

    // Suspension Stay Cables
    const cableCount = 8;
    [-30, 30].forEach((towerX) => {
      for (let i = 1; i <= cableCount; i++) {
        const offset = i * 4.5;
        const topAnchor = new THREE.Vector3(towerX, 45, 0);
        
        [towerX - offset, towerX + offset].forEach((deckX) => {
          if (Math.abs(deckX) <= 65) {
            [-6, 6].forEach((zSide) => {
              const deckAnchor = new THREE.Vector3(deckX, 16.3, zSide);
              const points = [new THREE.Vector3(towerX, 45, zSide * 0.4), deckAnchor];
              const cableGeo = new THREE.BufferGeometry().setFromPoints(points);
              const cableLine = new THREE.Line(cableGeo, cableMat);
              this.bridgeGroup.add(cableLine);
            });
          }
        });
      }
    });

    // Abutments at ends
    [-70, 70].forEach((abX, idx) => {
      const abutmentGeo = new THREE.BoxGeometry(10, 18, 18);
      const abutment = new THREE.Mesh(abutmentGeo, concreteMat);
      abutment.position.set(abX, 6, 0);
      abutment.userData = { name: `Abutment & Expansion Joint EJ-${idx + 1}`, health: 58, type: "Abutment" };
      this.bridgeGroup.add(abutment);
    });

    this.scene.add(this.bridgeGroup);
  }

  buildEnvironment() {
    // Water Surface
    const waterGeo = new THREE.PlaneGeometry(300, 300);
    const waterMat = new THREE.MeshStandardMaterial({
      color: 0x071E3D,
      roughness: 0.1,
      metalness: 0.9,
      transparent: true,
      opacity: 0.85
    });
    const water = new THREE.Mesh(waterGeo, waterMat);
    water.rotation.x = -Math.PI / 2;
    water.position.y = -2;
    water.receiveShadow = true;
    this.scene.add(water);

    // Grid Floor
    const grid = new THREE.GridHelper(300, 60, 0x00B4D8, 0x1B2A47);
    grid.position.y = -1.9;
    this.scene.add(grid);
  }

  addDefectHotspots() {
    const hotspotsData = [
      {
        pos: [-10, 16.5, 2],
        type: "Longitudinal Crack",
        code: "LC-01",
        severity: "Moderate (0.85mm)",
        component: "Bridge Deck Span D-04",
        color: 0xFFB703
      },
      {
        pos: [30, 8, 3],
        type: "Shear Crack & Efflorescence",
        code: "TC-02",
        severity: "Severe (1.42mm)",
        component: "Pier #2 Shear Column",
        color: 0xEF233C
      },
      {
        pos: [-45, 14, -5],
        type: "Spalling & Corroded Rebar",
        code: "RC-05",
        severity: "Critical (2.10mm cavity)",
        component: "Girder G-02 Flange",
        color: 0x9D4EDD
      },
      {
        pos: [70, 16.5, 0],
        type: "Expansion Joint Failure",
        code: "JD-07",
        severity: "Action Required",
        component: "Abutment Joint EJ-2",
        color: 0xFB8500
      }
    ];

    hotspotsData.forEach((data) => {
      const group = new THREE.Group();
      group.position.set(...data.pos);

      // Pulsing Core Sphere
      const sphereGeo = new THREE.SphereGeometry(1.2, 16, 16);
      const sphereMat = new THREE.MeshStandardMaterial({
        color: data.color,
        emissive: data.color,
        emissiveIntensity: 0.8,
        roughness: 0.2
      });
      const sphere = new THREE.Mesh(sphereGeo, sphereMat);
      sphere.userData = { ...data, isHotspot: true };
      group.add(sphere);

      // Outer Halo Ring
      const ringGeo = new THREE.RingGeometry(1.4, 1.8, 24);
      const ringMat = new THREE.MeshBasicMaterial({
        color: data.color,
        side: THREE.DoubleSide,
        transparent: true,
        opacity: 0.6
      });
      const ring = new THREE.Mesh(ringGeo, ringMat);
      ring.rotation.x = Math.PI / 2;
      group.add(ring);

      this.scene.add(group);
      this.hotspots.push({ group, sphere, ring, data });
    });
  }

  onResize() {
    if (!this.container || !this.renderer || !this.camera) return;
    const width = this.container.clientWidth;
    const height = this.container.clientHeight;
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
  }

  onMouseMove(event) {
    const rect = this.container.getBoundingClientRect();
    this.mouse.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
    this.mouse.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;
  }

  onClick(event) {
    this.raycaster.setFromCamera(this.mouse, this.camera);
    const intersects = this.raycaster.intersectObjects(this.scene.children, true);

    for (let hit of intersects) {
      if (hit.object.userData && hit.object.userData.isHotspot) {
        this.selectHotspot(hit.object.userData);
        return;
      }
    }
  }

  selectHotspot(data) {
    const infoPanel = document.getElementById('twin-inspection-card');
    if (!infoPanel) return;

    infoPanel.innerHTML = `
      <div style="border-left: 3px solid #${data.color.toString(16)}; padding-left: 10px;">
        <h4 style="color: var(--accent-cyan-glow); font-size: 0.95rem;">${data.type} [${data.code}]</h4>
        <p style="font-size: 0.8rem; color: var(--text-secondary); margin-top: 4px;"><b>Component:</b> ${data.component}</p>
        <p style="font-size: 0.8rem; color: var(--text-secondary);"><b>Severity:</b> ${data.severity}</p>
        <div style="margin-top: 10px;">
          <button class="btn-primary" style="padding: 6px 12px; font-size: 0.78rem;" onclick="loadPresetFrom3D('${data.code}')">
            Load AI Vision Scan
          </button>
        </div>
      </div>
    `;
  }

  animate() {
    this.animationId = requestAnimationFrame(() => this.animate());

    const time = Date.now() * 0.002;

    // Pulse Hotspots
    this.hotspots.forEach((h) => {
      const scale = 1.0 + 0.25 * Math.sin(time * 3);
      h.ring.scale.set(scale, scale, scale);
      h.ring.material.opacity = 0.8 - 0.3 * (scale - 1.0);
    });

    if (this.controls) {
      this.controls.update();
    }

    this.renderer.render(this.scene, this.camera);
  }
}

window.BridgeDigitalTwin = BridgeDigitalTwin;
