/**
 * BridgeVisionNet: Core Frontend Application Controller
 * Manages Dual AI inference, visual layer transitions, digital caliper, and reporting.
 */

let currentInspectionId = null;
let currentLayers = {};
let activeLayerKey = "composite";
let caliperMode = false;
let widthDistChart = null;
let telemetryManager = null;
let bridge3d = null;

document.addEventListener("DOMContentLoaded", () => {
  initTabs();
  initPresetChips();
  initFileUpload();
  initLayerButtons();
  initCaliperTool();
  initDistChart();
  initActionButtons();

  // Initialize Telemetry and 3D Twin
  telemetryManager = new BridgeTelemetryManager();
  
  // Trigger first sample analysis automatically
  runSampleInspection("sample_1");
});

// Tab Navigation
function initTabs() {
  const tabs = document.querySelectorAll(".nav-tab-btn");
  tabs.forEach((tab) => {
    tab.addEventListener("click", () => {
      tabs.forEach((t) => t.classList.remove("active"));
      document.querySelectorAll(".tab-pane").forEach((p) => p.classList.remove("active"));

      tab.classList.add("active");
      const targetId = tab.getAttribute("data-tab");
      const pane = document.getElementById(targetId);
      if (pane) pane.classList.add("active");

      // Lazy-load 3D Bridge when 3D tab is activated
      if (targetId === "tab-digital-twin") {
        if (!bridge3d) {
          bridge3d = new BridgeDigitalTwin("threejs-container");
        } else {
          bridge3d.onResize();
        }
      }
    });
  });
}

// Preset Samples
function initPresetChips() {
  const chips = document.querySelectorAll(".preset-chip");
  chips.forEach((chip) => {
    chip.addEventListener("click", () => {
      chips.forEach((c) => c.classList.remove("active"));
      chip.classList.add("active");
      const sampleId = chip.getAttribute("data-sample");
      runSampleInspection(sampleId);
    });
  });
}

// File Upload
function initFileUpload() {
  const dropZone = document.getElementById("drop-zone");
  const fileInput = document.getElementById("file-input");

  if (!dropZone || !fileInput) return;

  dropZone.addEventListener("click", () => fileInput.click());

  dropZone.addEventListener("dragover", (e) => {
    e.preventDefault();
    dropZone.style.borderColor = "var(--accent-cyan)";
  });

  dropZone.addEventListener("dragleave", () => {
    dropZone.style.borderColor = "var(--border-subtle)";
  });

  dropZone.addEventListener("drop", (e) => {
    e.preventDefault();
    dropZone.style.borderColor = "var(--border-subtle)";
    if (e.dataTransfer.files.length > 0) {
      handleCustomFileUpload(e.dataTransfer.files[0]);
    }
  });

  fileInput.addEventListener("change", () => {
    if (fileInput.files.length > 0) {
      handleCustomFileUpload(fileInput.files[0]);
    }
  });
}

// Layer Switcher
function initLayerButtons() {
  const btns = document.querySelectorAll(".layer-btn");
  btns.forEach((btn) => {
    btn.addEventListener("click", () => {
      btns.forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      activeLayerKey = btn.getAttribute("data-layer");
      applyActiveLayer();
    });
  });
}

function applyActiveLayer() {
  const imgEl = document.getElementById("main-canvas-img");
  if (!imgEl) return;

  if (currentLayers && currentLayers[activeLayerKey]) {
    imgEl.src = currentLayers[activeLayerKey];
  }
}

// Interactive Digital Caliper Tool
function initCaliperTool() {
  const caliperBtn = document.getElementById("toggle-caliper-btn");
  const canvasWrapper = document.getElementById("canvas-wrapper");
  const marker = document.getElementById("caliper-marker");
  const callout = document.getElementById("caliper-callout");

  if (!caliperBtn || !canvasWrapper) return;

  caliperBtn.addEventListener("click", () => {
    caliperMode = !caliperMode;
    caliperBtn.classList.toggle("active", caliperMode);
    caliperBtn.innerText = caliperMode ? "\u2702 Caliper Active (Click on Crack)" : "\u2699 Digital Caliper";
    
    if (!caliperMode) {
      if (marker) marker.style.display = "none";
      if (callout) callout.style.display = "none";
    }
  });

  canvasWrapper.addEventListener("click", async (e) => {
    if (!caliperMode || !currentInspectionId) return;

    const rect = canvasWrapper.getBoundingClientRect();
    const imgEl = document.getElementById("main-canvas-img");
    if (!imgEl) return;

    const clickX = e.clientX - rect.left;
    const clickY = e.clientY - rect.top;

    // Calculate actual pixel coordinates relative to original image size
    const imgNaturalW = imgEl.naturalWidth || 800;
    const imgNaturalH = imgEl.naturalHeight || 800;
    const imgDisplayW = imgEl.clientWidth;
    const imgDisplayH = imgEl.clientHeight;

    const scaleX = imgNaturalW / imgDisplayW;
    const scaleY = imgNaturalH / imgDisplayH;

    const imgOffsetX = (rect.width - imgDisplayW) / 2;
    const imgOffsetY = (rect.height - imgDisplayH) / 2;

    const targetX = Math.round((clickX - imgOffsetX) * scaleX);
    const targetY = Math.round((clickY - imgOffsetY) * scaleY);

    if (marker) {
      marker.style.left = `${clickX}px`;
      marker.style.top = `${clickY}px`;
      marker.style.display = "block";
    }

    try {
      const resp = await fetch("/api/metrology/caliper", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          inspection_id: currentInspectionId,
          point_x: targetX,
          point_y: targetY
        })
      });

      const data = await resp.json();
      if (callout) {
        if (data.valid) {
          callout.innerHTML = `<b>Width:</b> ${data.width_mm} mm (${data.width_px} px)<br/><span style="color:#FFF;">Scale: ${data.scale_mm_per_pixel} mm/px</span>`;
        } else {
          callout.innerText = "No crack detected at point";
        }
        callout.style.left = `${Math.min(clickX + 15, rect.width - 150)}px`;
        callout.style.top = `${Math.max(clickY - 25, 10)}px`;
        callout.style.display = "block";
      }
    } catch (err) {
      console.error("Caliper error:", err);
    }
  });
}

// Crack Width Distribution Chart
function initDistChart() {
  const ctx = document.getElementById("crackWidthDistCanvas")?.getContext("2d");
  if (!ctx) return;

  widthDistChart = new Chart(ctx, {
    type: "bar",
    data: {
      labels: [],
      datasets: [{
        label: "Segment Count",
        data: [],
        backgroundColor: "rgba(0, 180, 216, 0.7)",
        borderColor: "#00B4D8",
        borderWidth: 1,
        borderRadius: 4
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        x: {
          grid: { color: "rgba(255, 255, 255, 0.05)" },
          ticks: { color: "#94A3B8", font: { family: "JetBrains Mono", size: 9 } }
        },
        y: {
          grid: { color: "rgba(255, 255, 255, 0.05)" },
          ticks: { color: "#94A3B8", font: { family: "JetBrains Mono", size: 9 } }
        }
      },
      plugins: {
        legend: { display: false }
      }
    }
  });
}

// Inspection Execution
async function runSampleInspection(sampleId) {
  setLoadingState(true);
  const formData = new FormData();
  formData.append("sample_id", sampleId);
  formData.append("mm_per_pixel", document.getElementById("slider-scale")?.value || "0.25");
  formData.append("yolo_conf", document.getElementById("slider-conf")?.value || "0.35");
  formData.append("unet_thresh", document.getElementById("slider-mask")?.value || "0.40");

  try {
    const response = await fetch("/api/inspect", {
      method: "POST",
      body: formData
    });

    if (!response.ok) throw new Error("Inspection failed");
    const data = await response.json();
    populateInspectionUI(data);
  } catch (e) {
    console.error("Failed to run sample inspection:", e);
    alert("Error performing bridge inspection: " + e.message);
  } finally {
    setLoadingState(false);
  }
}

async function handleCustomFileUpload(file) {
  setLoadingState(true);
  const formData = new FormData();
  formData.append("file", file);
  formData.append("mm_per_pixel", document.getElementById("slider-scale")?.value || "0.25");
  formData.append("yolo_conf", document.getElementById("slider-conf")?.value || "0.35");
  formData.append("unet_thresh", document.getElementById("slider-mask")?.value || "0.40");
  formData.append("component_name", "Uploaded Drone Inspection Feed");

  try {
    const response = await fetch("/api/inspect", {
      method: "POST",
      body: formData
    });

    if (!response.ok) throw new Error("Upload inspection failed");
    const data = await response.json();
    populateInspectionUI(data);
  } catch (e) {
    console.error("Failed to run custom inspection:", e);
    alert("Error inspecting uploaded file: " + e.message);
  } finally {
    setLoadingState(false);
  }
}

// UI Population
function populateInspectionUI(data) {
  currentInspectionId = data.inspection_id;
  currentLayers = data.layers;

  // 1. Update Canvas Viewport
  applyActiveLayer();

  // 2. Hide Caliper markers
  const marker = document.getElementById("caliper-marker");
  const callout = document.getElementById("caliper-callout");
  if (marker) marker.style.display = "none";
  if (callout) callout.style.display = "none";

  // 3. Update Inference Metrics
  const fpsEl = document.getElementById("metric-fps");
  const latEl = document.getElementById("metric-latency");
  if (fpsEl) fpsEl.innerText = `${data.metrics.fps} FPS`;
  if (latEl) latEl.innerText = `${data.metrics.total_time_ms} ms (YOLO: ${data.metrics.yolo_time_ms}ms, U-Net++: ${data.metrics.unet_time_ms}ms)`;

  // 4. Update Health Gauge & AASHTO State
  const health = data.health_assessment;
  const shiScore = health.structural_health_index;
  const scoreEl = document.getElementById("shi-score-val");
  const circleEl = document.getElementById("shi-circle-gauge");
  const ratingTag = document.getElementById("aashto-rating-tag");
  const ratingDesc = document.getElementById("aashto-rating-desc");
  const urgencyEl = document.getElementById("maintenance-urgency-val");

  if (scoreEl) scoreEl.innerText = shiScore;
  if (circleEl) {
    circleEl.style.borderColor = health.rating_color;
    circleEl.style.boxShadow = `0 0 20px ${health.rating_color}60`;
  }
  if (ratingTag) {
    ratingTag.innerText = `${health.condition_state} (${health.rating_label})`;
    ratingTag.style.color = health.rating_color;
    ratingTag.style.borderColor = health.rating_color;
    ratingTag.style.background = `${health.rating_color}18`;
  }
  if (ratingDesc) ratingDesc.innerText = health.description;
  if (urgencyEl) urgencyEl.innerText = `Urgency: ${health.urgency}`;

  // 5. Update Metrology Stat Cards
  const m = data.metrology;
  setElementText("stat-max-w", `${m.max_width_mm} mm`);
  setElementText("stat-avg-w", `${m.avg_width_mm} mm`);
  setElementText("stat-p95-w", `${m.p95_width_mm} mm`);
  setElementText("stat-length", `${m.total_length_mm} mm`);
  setElementText("stat-area", `${m.surface_area_mm2} mm\u00B2`);
  setElementText("stat-orient", `${m.orientation_deg}\u00B0`);
  setElementText("stat-branches", `${m.branch_count}`);

  // 6. Update Width Distribution Chart
  if (widthDistChart && m.width_distribution) {
    widthDistChart.data.labels = m.width_distribution.map(d => d.bin);
    widthDistChart.data.datasets[0].data = m.width_distribution.map(d => d.count);
    widthDistChart.update();
  }

  // 7. Update Defects Table
  const tableBody = document.getElementById("defects-table-body");
  if (tableBody) {
    tableBody.innerHTML = "";
    if (data.detections.length === 0) {
      tableBody.innerHTML = `<tr><td colspan="4" style="text-align:center; color: var(--text-muted);">No major defects localized</td></tr>`;
    } else {
      data.detections.forEach((d, idx) => {
        const tr = document.createElement("tr");
        tr.innerHTML = `
          <td>DEF-${(idx + 1).toString().padStart(2, "0")}</td>
          <td><span class="class-pill" style="background:${d.color}22; color:${d.color}; border:1px solid ${d.color}66;">${d.class_name}</span></td>
          <td style="font-family: var(--font-mono);">${Math.round(d.score * 100)}%</td>
          <td style="font-family: var(--font-mono);">${d.severity_weight}x</td>
        `;
        tableBody.appendChild(tr);
      });
    }
  }

  // 8. Update Recommendations
  const recList = document.getElementById("recommendations-list");
  if (recList && health.recommendations) {
    recList.innerHTML = "";
    health.recommendations.forEach((r) => {
      const li = document.createElement("li");
      li.innerText = r;
      recList.appendChild(li);
    });
  }

  // 9. Sync Telemetry Severity with Defect Index
  if (telemetryManager) {
    const severityRatio = (100.0 - shiScore) / 100.0;
    telemetryManager.setSeverity(severityRatio);
  }
}

function setElementText(id, text) {
  const el = document.getElementById(id);
  if (el) el.innerText = text;
}

function setLoadingState(isLoading) {
  const spinner = document.getElementById("scan-spinner");
  const btnText = document.getElementById("scan-btn-text");
  if (spinner) spinner.style.display = isLoading ? "inline-block" : "none";
  if (btnText) btnText.innerText = isLoading ? "Processing Neural Pipeline..." : "Execute AI Scan";
}

// Action Buttons (PDF & CSV Export)
function initActionButtons() {
  const scanBtn = document.getElementById("run-scan-btn");
  if (scanBtn) {
    scanBtn.addEventListener("click", () => {
      const activeChip = document.querySelector(".preset-chip.active");
      if (activeChip) {
        runSampleInspection(activeChip.getAttribute("data-sample"));
      } else {
        runSampleInspection("sample_1");
      }
    });
  }

  const pdfBtn = document.getElementById("btn-download-pdf");
  if (pdfBtn) {
    pdfBtn.addEventListener("click", async () => {
      if (!currentInspectionId) {
        alert("Please run an inspection first.");
        return;
      }
      pdfBtn.innerText = "\u23F3 Building PDF...";
      try {
        const resp = await fetch("/api/report/pdf", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ inspection_id: currentInspectionId })
        });
        if (!resp.ok) throw new Error("PDF generation failed");
        const blob = await resp.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = `Bridge_Inspection_Report_${currentInspectionId}.pdf`;
        a.click();
      } catch (e) {
        alert("Error generating PDF: " + e.message);
      } finally {
        pdfBtn.innerHTML = `<svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg> Download Official PDF Report`;
      }
    });
  }

  const csvBtn = document.getElementById("btn-export-csv");
  if (csvBtn) {
    csvBtn.addEventListener("click", async () => {
      if (!currentInspectionId) {
        alert("Please run an inspection first.");
        return;
      }
      try {
        const resp = await fetch("/api/report/csv", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ inspection_id: currentInspectionId })
        });
        if (!resp.ok) throw new Error("CSV generation failed");
        const blob = await resp.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = `Inspection_${currentInspectionId}_data.csv`;
        a.click();
      } catch (e) {
        alert("Error exporting CSV: " + e.message);
      }
    });
  }

  // Slider change listeners
  ["slider-scale", "slider-conf", "slider-mask"].forEach((id) => {
    const slider = document.getElementById(id);
    const valSpan = document.getElementById(`${id}-val`);
    if (slider && valSpan) {
      slider.addEventListener("input", () => {
        valSpan.innerText = slider.value + (id === "slider-scale" ? " mm/px" : "");
      });
    }
  });
}

// 3D Hotspot Trigger Helper
window.loadPresetFrom3D = function(code) {
  const codeMap = {
    "LC-01": "sample_1",
    "TC-02": "sample_2",
    "RC-05": "sample_3",
    "JD-07": "sample_5"
  };
  const sampleId = codeMap[code] || "sample_1";
  
  // Switch to Tab 1
  const studioTab = document.querySelector('[data-tab="tab-studio"]');
  if (studioTab) studioTab.click();

  // Activate chip
  const targetChip = document.querySelector(`[data-sample="${sampleId}"]`);
  if (targetChip) {
    document.querySelectorAll(".preset-chip").forEach(c => c.classList.remove("active"));
    targetChip.classList.add("active");
  }

  runSampleInspection(sampleId);
};
