/**
 * BridgeVisionNet: IoT Structural Health Telemetry & Modal FFT Analysis
 * Powered by Chart.js
 */

class BridgeTelemetryManager {
  constructor() {
    this.waveformChart = null;
    this.fftChart = null;
    this.crackSeverity = 0.2;
    this.intervalId = null;

    this.initCharts();
    this.startLiveStream();
  }

  initCharts() {
    // 1. Waveform Chart
    const waveCtx = document.getElementById('telemetryWaveformCanvas')?.getContext('2d');
    if (waveCtx) {
      this.waveformChart = new Chart(waveCtx, {
        type: 'line',
        data: {
          labels: Array.from({ length: 50 }, (_, i) => `${(i * 0.04).toFixed(2)}s`),
          datasets: [{
            label: 'Tri-Axial Accelerometer (g)',
            data: new Array(50).fill(0),
            borderColor: '#00B4D8',
            backgroundColor: 'rgba(0, 180, 216, 0.08)',
            borderWidth: 1.8,
            fill: true,
            tension: 0.35,
            pointRadius: 0
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          animation: { duration: 150 },
          scales: {
            x: {
              grid: { color: 'rgba(255, 255, 255, 0.05)' },
              ticks: { color: '#64748B', font: { family: 'JetBrains Mono', size: 10 }, maxTicksLimit: 8 }
            },
            y: {
              min: -0.35,
              max: 0.35,
              grid: { color: 'rgba(255, 255, 255, 0.05)' },
              ticks: { color: '#64748B', font: { family: 'JetBrains Mono', size: 10 } }
            }
          },
          plugins: {
            legend: { display: false },
            tooltip: { enabled: true }
          }
        }
      });
    }

    // 2. FFT Power Spectral Density Chart
    const fftCtx = document.getElementById('telemetryFftCanvas')?.getContext('2d');
    if (fftCtx) {
      this.fftChart = new Chart(fftCtx, {
        type: 'bar',
        data: {
          labels: [],
          datasets: [{
            label: 'Spectral Amplitude |PSD|',
            data: [],
            backgroundColor: 'rgba(157, 78, 221, 0.7)',
            borderColor: '#C77DFF',
            borderWidth: 1,
            borderRadius: 3
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          animation: { duration: 250 },
          scales: {
            x: {
              grid: { color: 'rgba(255, 255, 255, 0.05)' },
              ticks: { color: '#64748B', font: { family: 'JetBrains Mono', size: 10 }, maxTicksLimit: 10 }
            },
            y: {
              grid: { color: 'rgba(255, 255, 255, 0.05)' },
              ticks: { color: '#64748B', font: { family: 'JetBrains Mono', size: 10 } }
            }
          },
          plugins: {
            legend: { display: false }
          }
        }
      });
    }
  }

  setSeverity(severityRatio) {
    this.crackSeverity = Math.max(0.0, Math.min(1.0, severityRatio));
  }

  async fetchTelemetryUpdate() {
    try {
      const response = await fetch(`/api/telemetry/live?severity=${this.crackSeverity}`);
      if (!response.ok) return;
      const data = await response.json();

      this.updateUI(data);
    } catch (e) {
      // Background poll silently retry
    }
  }

  updateUI(data) {
    // 1. Update Waveform
    if (this.waveformChart && data.waveform) {
      this.waveformChart.data.datasets[0].data = data.waveform;
      this.waveformChart.update('none');
    }

    // 2. Update FFT Spectrum
    if (this.fftChart && data.fft_spectrum) {
      this.fftChart.data.labels = data.fft_spectrum.map(s => `${s.freq} Hz`);
      this.fftChart.data.datasets[0].data = data.fft_spectrum.map(s => s.amplitude);
      this.fftChart.update('none');
    }

    // 3. Update Modal Frequency Badges
    const mf = data.modal_frequencies_hz;
    const s = data.sensors;

    const m1El = document.getElementById('iot-m1-val');
    if (m1El) m1El.innerText = `${mf.mode_1_bending} Hz`;

    const m2El = document.getElementById('iot-m2-val');
    if (m2El) m2El.innerText = `${mf.mode_2_bending} Hz`;

    const dropEl = document.getElementById('iot-drop-val');
    if (dropEl) {
      dropEl.innerText = `-${mf.frequency_drop_pct}%`;
      dropEl.className = mf.frequency_drop_pct > 15 ? 'stat-val text-red' : (mf.frequency_drop_pct > 5 ? 'stat-val text-amber' : 'stat-val text-green');
    }

    const strainEl = document.getElementById('iot-strain-val');
    if (strainEl) strainEl.innerText = `${s.microstrain_ue} \u03bc\u03b5`;

    const deflEl = document.getElementById('iot-defl-val');
    if (deflEl) deflEl.innerText = `${s.midspan_deflection_mm} mm`;

    const tiltEl = document.getElementById('iot-tilt-val');
    if (tiltEl) tiltEl.innerText = `${s.pier_tilt_arcmin} '`;

    const peakAccEl = document.getElementById('iot-acc-val');
    if (peakAccEl) peakAccEl.innerText = `${s.peak_acceleration_g} g`;
  }

  startLiveStream() {
    this.fetchTelemetryUpdate();
    this.intervalId = setInterval(() => this.fetchTelemetryUpdate(), 1000);
  }

  stopLiveStream() {
    if (this.intervalId) clearInterval(this.intervalId);
  }
}

window.BridgeTelemetryManager = BridgeTelemetryManager;
