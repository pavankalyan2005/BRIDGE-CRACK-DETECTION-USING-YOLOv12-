# Core module initialization
from core.config import *
from core.logger import logger
