"""
Comprehensive System Verification Test for BridgeVisionNet
Tests U-Net++, YOLOv12, Crack Metrology, IoT Telemetry, and PDF Generator.
"""

import sys
import numpy as np

from core.config import SAMPLE_DIR
from ai_engine.pipeline import BridgeVisionPipeline
from reporting.pdf_generator import generate_inspection_pdf
from reporting.csv_exporter import export_inspection_csv
from telemetry.iot_simulator import telemetry_simulator

def run_tests():
    print("=" * 60)
    print("BRIDGEVISIONNET: EXECUTING FULL SYSTEM VERIFICATION SUITE")
    print("=" * 60)

    # 1. Test Pipeline Initialization
    print("[1/5] Initializing Dual AI Pipeline (YOLOv12 + U-Net++)...")
    pipeline = BridgeVisionPipeline()
    print("      Dual AI Pipeline initialized successfully!")

    # 2. Test Inference on Sample Images
    print("[2/5] Testing AI Inference & Metrology on Concrete Sample...")
    sample_file = SAMPLE_DIR / "sample_1_deck_longitudinal_crack.jpg"
    if not sample_file.exists():
        raise FileNotFoundError(f"Sample file {sample_file} does not exist.")

    result = pipeline.inspect(
        image_input=str(sample_file),
        mm_per_pixel=0.25,
        component_name="Golden Gate Deck Span D-04"
    )

    print(f"      Inference Time: {result['inference_metrics']['total_time_ms']} ms ({result['inference_metrics']['fps']} FPS)")
    print(f"      Detections Count: {len(result['detections'])}")
    for d in result['detections']:
        print(f"        - {d['class_name']}: {round(d['score']*100, 1)}% conf, Box: {[int(x) for x in d['box']]}")
    
    metro = result['metrology']
    print(f"      Crack Max Width: {metro['max_width_mm']} mm, Avg Width: {metro['avg_width_mm']} mm")
    print(f"      Crack Total Length: {metro['total_length_mm']} mm, Area: {metro['surface_area_mm2']} mm2")
    print(f"      Orientation: {metro['orientation_deg']} deg ({metro['orientation_type']})")

    health = result['health_assessment']
    print(f"      Structural Health Index (SHI): {health['structural_health_index']}/100")
    print(f"      AASHTO Rating: {health['condition_state']} ({health['rating_label']})")
    print(f"      Urgency: {health['urgency']}")

    # 3. Test IoT Telemetry Simulator
    print("[3/5] Testing IoT Sensor Telemetry & Modal FFT Engine...")
    telem = telemetry_simulator.generate_telemetry_frame(crack_severity_ratio=0.25)
    print(f"      Modal Frequencies: Mode 1 = {telem['modal_frequencies_hz']['mode_1_bending']} Hz, Drop = {telem['modal_frequencies_hz']['frequency_drop_pct']}%")
    print(f"      Sensors: Strain = {telem['sensors']['microstrain_ue']} ue, Deflection = {telem['sensors']['midspan_deflection_mm']} mm")

    # 4. Test PDF Report Generation
    print("[4/5] Testing PDF ReportLab Structural Certificate Generator...")
    pdf_path = generate_inspection_pdf(
        inspection_id="TEST-9988",
        inspection_data=result,
        bridge_name="Golden Gate North Viaduct (Pier 4)",
        structure_id="BR-CIV-2026-904"
    )
    print(f"      PDF Report generated successfully at: {pdf_path}")

    # 5. Test CSV Exporter
    print("[5/5] Testing CSV Data Exporter...")
    csv_path = export_inspection_csv(
        inspection_id="TEST-9988",
        data=result
    )
    print(f"      CSV Export generated successfully at: {csv_path}")

    print("=" * 60)
    print("ALL 5 CORE SUBSYSTEM VERIFICATION TESTS PASSED PERFECTLY!")
    print("=" * 60)

if __name__ == "__main__":
    run_tests()
