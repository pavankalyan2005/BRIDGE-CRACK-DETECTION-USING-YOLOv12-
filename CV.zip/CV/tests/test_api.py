"""
FastAPI REST API Verification Tests
"""

from fastapi.testclient import TestClient
from app import app

client = TestClient(app)

def test_api():
    print("Testing GET / ...")
    resp = client.get("/")
    assert resp.status_code == 200
    assert "BridgeVisionNet" in resp.text
    print("  GET / passed!")

    print("Testing GET /api/samples ...")
    resp = client.get("/api/samples")
    assert resp.status_code == 200
    samples = resp.json()["samples"]
    assert len(samples) >= 6
    print(f"  GET /api/samples passed! Found {len(samples)} preset scenarios.")

    print("Testing POST /api/inspect (Sample 1) ...")
    resp = client.post("/api/inspect", data={"sample_id": "sample_1", "mm_per_pixel": 0.25})
    assert resp.status_code == 200
    data = resp.json()
    assert "inspection_id" in data
    assert "layers" in data
    assert "composite" in data["layers"]
    assert "metrology" in data
    insp_id = data["inspection_id"]
    print(f"  POST /api/inspect passed! Generated inspection ID: {insp_id}")

    print("Testing POST /api/metrology/caliper ...")
    resp = client.post("/api/metrology/caliper", json={"inspection_id": insp_id, "point_x": 400, "point_y": 400})
    assert resp.status_code == 200
    caliper_data = resp.json()
    print(f"  POST /api/metrology/caliper passed! Caliper result: {caliper_data}")

    print("Testing GET /api/telemetry/live ...")
    resp = client.get("/api/telemetry/live?severity=0.3")
    assert resp.status_code == 200
    telem = resp.json()
    assert "fft_spectrum" in telem
    print("  GET /api/telemetry/live passed!")

    print("Testing POST /api/report/pdf ...")
    resp = client.post("/api/report/pdf", json={"inspection_id": insp_id})
    assert resp.status_code == 200
    assert resp.headers["content-type"] == "application/pdf"
    print(f"  POST /api/report/pdf passed! PDF size: {len(resp.content)} bytes")

    print("Testing POST /api/report/csv ...")
    resp = client.post("/api/report/csv", json={"inspection_id": insp_id})
    assert resp.status_code == 200
    print(f"  POST /api/report/csv passed! CSV size: {len(resp.content)} bytes")

    print("Testing GET /api/system/status ...")
    resp = client.get("/api/system/status")
    assert resp.status_code == 200
    print("  GET /api/system/status passed!")

    print("ALL API ENDPOINTS FUNCTIONING 100% WITHOUT ERROR!")

if __name__ == "__main__":
    test_api()
